package com.example.recycle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

public class RkAdapter extends RecyclerView.Adapter<RkAdapter.ListViewHolder> {
    private ArrayList<Rk> listRk;

    public RkAdapter(ArrayList<Rk> list) {
        this.listRk = list;
    }
    @NonNull
    @Override
    public ListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_rk, parent, false);
        return new ListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ListViewHolder holder, int position) {
        Rk rk = listRk.get(position);
        Glide.with(holder.itemView.getContext())
                .load(rk.getLogo())
                .apply(new RequestOptions().override(75,75))
                .into(holder.imgLogo);
        holder.namaRk.setText(rk.getNamark());
        holder.desRk.setText(rk.getDesrk());
    }

    @Override
    public int getItemCount() {
        return listRk.size();
    }

    public class ListViewHolder extends RecyclerView.ViewHolder {
        ImageView imgLogo;
        TextView namaRk;
        TextView desRk;

        ListViewHolder(View itemview) {
            super(itemview);
            imgLogo = itemview.findViewById(R.id.logo);
            namaRk = itemview.findViewById(R.id.namark);
            desRk = itemview.findViewById(R.id.desrk);
        }
    }
}
