package com.example.recycle;

public class Rk {
    private String namark;
    private String desrk;
    private int logo;

    public String getNamark() {
        return namark;
    }

    public void setNamark(String namark) {
        this.namark = namark;
    }

    public String getDesrk() {
        return desrk;
    }

    public void setDesrk(String desrk) {
        this.desrk = desrk;
    }

    public int getLogo() {
        return logo;
    }

    public void setLogo(int logo) {
        this.logo = logo;
    }
}
