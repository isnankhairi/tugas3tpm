package com.example.recycle;

import java.util.ArrayList;

public class DataRk {
    private static String [] namaRk = {
            "Omegamon",
            "Alphamon",
            "Examon",
            "Gallantmon",
            "UlforceVeedramon",
            "Magnamon",
            "Dynasmon",
            "LordKnightmon",
            "Sleipmon",
            "Craniumon",
            "Duftmon",
            "Gankoomon",
            "Jesmon"
    };

    private static String [] desRk = {
            "Omegamon bisa dibilang adalah anggota yang paling terkenal sekaligus Wakil Pemimpin Royal Knights. Dia menjadi pemimpin jika Alphamon tidak ada.",
            "Alphamon merupakan evolusi terakhir dari Dorumon, Digimon yang diasingkan karena memiliki X-Antibody serta merupakan leader dari Royal Knights",
            "Examon adalah satu-satunya Royal Knights yang tidak terlihat seperti kesatria. Wujud Examon lebih mirip seperti naga.",
            "Dukemon memiliki senjata berupa tombak bernama Gram dan perisai bernama Aegis. Hal ini membuatnya mampu menyerang dan bertahan sama baiknya.",
            " Dia adalah Ulforce V-dramon yang memiliki kecepatan tertinggi di antara Royal Knights dan tidak ada yang menandingi kecepatannya. ",
            "Meski level perubahannya adalah armor, Magnamon mampu bersanding dengan 12 Digimon ber-level Ultimate.Tubuhnya dilindungi armor yang terbuat dari Chrome Digizoid. ",
            "Salah satu Holy Knight yang memiliki kekuatan makhluk bernama wyvern di antara Royal Knights. Dia mewujudkan rasa keadilan versinya sendiri.",
            "Meski terkesan feminim dengan armor berwarna pink/magenta, tidak membuat Digimon yang satu ini bersikap ramah, justru dia sangat arogan.",
            "Sleipmon adalah penjaga reruntuhan kuno yang berada di kutub utara Dunia Digital. Sleipmon berbentuk seperti kuda dengan enam kaki.  ",
            "Craniummon adalah anggota Royal Knights yang perfeksionis dan senang bersaing dengan Royal Knights lainnya untuk menyelesaikan misi dari Yggdrasill.",
            "Di antara anggota Royal Knights, dirinya dikenal sebagai ahli strategi dan memiliki kemampuan untuk merencakan strategi serangan.",
            "Gankoomon merupakan anggota Royal Knights yang tinggal di daerah barat daya Dunia Digital.",
            "Jesmon disebut sebagai ahli pedang Royal Knights. Soalnya, seluruh tubuhnya, bahkan kaki, tangan, dan ekornya berbentuk seperti pedang."
    };

    private static int [] logoRk = {
            R.drawable.ork,
            R.drawable.aork,
            R.drawable.exark,
            R.drawable.gallantrk,
            R.drawable.uvrk,
            R.drawable.magnark,
            R.drawable.dynasrk,
            R.drawable.lkrk,
            R.drawable.sleiprk,
            R.drawable.cranirk,
            R.drawable.duftrk,
            R.drawable.gankoork,
            R.drawable.jesrk
    };

    static ArrayList<Rk> getListData(){
        ArrayList<Rk> list = new ArrayList<>();
        for (int position = 0; position <namaRk.length; position++){
            Rk rk = new Rk();
            rk.setNamark(namaRk[position]);
            rk.setDesrk(desRk[position]);
            rk.setLogo(logoRk[position]);
            list.add(rk);
        }
        return list;
    }
}
